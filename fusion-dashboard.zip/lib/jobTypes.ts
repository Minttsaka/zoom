export const jobTypes = [
    {
      name: 'FullTime',
      description: 'Employees work a standard number of hours per week (typically 40 hours) and are entitled to benefits such as healthcare, paid time off, and retirement plans.',
    },
{
      name: 'PartTime',
      description: 'Employees work fewer hours than full-time employees and may not receive the same benefits.',
    },
    {
      name: 'Contract',
      description: 'Employees work for a fixed period of time or until a specific project is completed. They may be hired directly by the company or through a third-party contractor.',
    },
    {
      name: 'Temporary',
      description: 'Similar to contract employees, temporary employees work for a fixed period of time but may be hired to cover seasonal or short-term needs.',
    },
     {
      name: 'Freelance',
      description: 'Freelancers are self-employed individuals who work on a project basis for multiple clients. They are not employees of the company and typically work remotely.',
    },
     {
      name: 'Internship',
      description: 'Interns are usually students or recent graduates who gain practical experience in a specific field or industry. Internships may be paid or unpaid.',
    },
     {
      name: 'Remote',
      description: 'Employees work remotely from a location outside of the company\'s office. Remote work may be full-time or part-time.',
    },
     {
      name: 'Consultant',
      description: 'Consultants are experts in a particular field who provide advice and expertise to organizations on a contractual basis.',
    },
    {
      name: 'ShiftBased',
      description: 'Employees work specific shifts or hours, such as morning, afternoon, or night shifts, depending on the needs of the organization.',
    }
  ];
  

  