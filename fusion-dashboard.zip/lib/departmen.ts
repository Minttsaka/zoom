export const departments = [
    { value: 'EXECUTIVE', label: 'Executive' },
    { value: 'PRODUCT_DEVELOPMENT', label: 'Product Development' },
    { value: 'SOFTWARE_ENGINEER', label: 'Software Engineer' },
    { value: 'LIBRARIAN', label: 'Librarian' },
    { value: 'CONTENT_CREATION', label: 'Content Creation' },
    { value: 'RESEARCH_AND_DEVELOPMENT', label: 'Research and Development' },
    { value: 'MARKETING_AND_SALES', label: 'Marketing and Sales' },
    { value: 'CUSTOMER_SUPPORT', label: 'Customer Support' },
    { value: 'QUALITY_ASSURANCE', label: 'Quality Assurance' },
    { value: 'DATA_ANALYTICS_AND_INSIGHTS', label: 'Data Analytics and Insights' },
    { value: 'OPERATIONS_AND_ADMINISTRATION', label: 'Operations and Administration' },
    { value: 'PARTNERSHIPS_AND_ALLIANCES', label: 'Partnerships and Alliances' },
  ];
  
 