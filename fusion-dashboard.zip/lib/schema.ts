export interface SocialMediaEntry {
    path: string; 
    url: string; 
  }

export type User = {
    id         : string, 
    firstName  : string,
    lastName   : string,
    profilePic : string,
    email      : string,  
    jobType    : string,
    password   : string, 
    gender     : string,
    startDate  : string,
    address    : string,
    department : string,
    isActive   : boolean,
    salary     : string,
    role       : string,
    bio        : string,
    socialMedia: SocialMediaEntry
  }

  export const Role = [
    'CEO',
    'COO',
    'CFO',
    'CTO',
    'CMO',
    'CIO',
    'CHRO',
    'Chief_Educational_Officer',
    'Vice_President',
    'Director',
    'Manager',
    'Supervisor',
    'Team_Lead',
    'Specialist',
    'Analyst',
    'Coordinator',
    'Administrator',
    'Assistant',
    'Staff',
    'Intern',
  ] as const;
  

  export const Department = [
    "EXECUTIVE",
    "PRODUCT_DEVELOPMENT",
    "SOFTWARE_ENGINEER",
    "LIBRARIAN",
    "CONTENT_CREATION",
    "RESEARCH_AND_DEVELOPMENT",
    "MARKETING_AND_SALES",
    "CUSTOMER_SUPPORT",
    "QUALITY_ASSURANCE",
    "DATA_ANALYTICS_AND_INSIGHTS",
    "OPERATIONS_AND_ADMINISTRATION",
    "PARTNERSHIPS_AND_ALLIANCES",
   ] as const

  export const Gender = ["MALE","FEMALE"] as const;
  

  export const JobType = [
    'FullTime',
    'PartTime',
    'Contract',
    'Temporary',
    'Freelance',
    'Internship',
    'Remote',
    'Consultant',
    'ShiftBased',
  ] as const;
  