import type { Metadata } from "next";
import { Providers } from './providers';
import "./globals.css";
import { Comfortaa } from 'next/font/google'
import { Toaster } from "@/components/ui/sonner"

// const comfortaa = Comfortaa({
//   subsets: ['latin'],
//   display: 'swap',
//   variable: '--font-comfortaa',
// })



export const metadata: Metadata = {
  title: "WELCOME TO DCTFUSION TEAM",
  description: "DCTFUSION",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body  >
        <Providers>
          {children}
          <Toaster />
        </Providers>
        </body>
    </html>
  );
}
