import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req:Request){

    const origin=req.headers.get('origin')

    try {
        
    const impacts = await prisma.impact.findMany();

      return new NextResponse(JSON.stringify(impacts),{
        headers: {
            'Access-Control-Allow-Origin': origin || "*",
            'Content-Type':'application/json',
          },
    })
    } catch (error) {
      return
    }


}