
import { NextResponse } from 'next/server';
import { Prisma, PrismaClient } from '@prisma/client';
import { getServerSession } from "next-auth";
import { authOptions } from '@/lib/auth';

const prisma = new PrismaClient();

interface UserData {
    id: string;
  }

  export async function POST(req: Request, res: Response) {

    const session:any = await getServerSession(authOptions);
    const userId = (session.user as UserData)?.id;

   
  try {

    const user = await prisma.user.findFirst({
        where: { id: userId }, 
        include: {
            socialMedia: true,
          },
      });

      if(user?.password){
        const {password,...userData}=user
        return NextResponse.json({ userData});
      }

  } catch (error) {
    console.error('Error creating user:', error);
    throw error; 
  } finally {
    await prisma.$disconnect();
  }
}
