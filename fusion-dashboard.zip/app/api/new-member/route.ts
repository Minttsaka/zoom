import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';
import { signJwt } from '@/lib/jwt'; // Assuming you have a function for signing JWT tokens
import { z } from 'zod';
import { NextResponse } from 'next/server';
import { Department, Gender, JobType, Role } from '@/lib/schema';

const prisma = new PrismaClient();


  
  const DataSchema = z.object({
    firstName: z
      .string()
      .min(2, "First name must be at least 2 characters")
      .max(45, "First name must be less than 45 characters")
      .regex(new RegExp("^[a-zA-Z]+$"), "No special character allowed!"),
    lastName: z
      .string()
      .min(2, "Last name must be at least 2 characters")
      .max(45, "Last name must be less than 45 characters")
      .regex(new RegExp("^[a-zA-Z]+$"), "No special character allowed!"),
    companyEmail: z.string().email("Please enter a valid company email address"),
    startDate: z.string().transform((val) => new Date(val)), // Transform startDate to a Date object
    address: z.string(),
    salary: z.string().min(0), // Assuming salary is a number and must be non-negative
  });

  const FormSchema=z.object({
    gender: z
        .enum(Gender),
    password: z
        .string()
        .min(2, "First name must be at least 2 characters")
        .max(45, "First name must be less than 45 characters"),
    isActive: z
        .boolean(),
    jobType: z
        .enum(JobType),
    jobRole: z
        .enum(Role),
    department: z
        .enum(Department),
    data:DataSchema
  })
  

  export async function POST(req: Request, res: Response) {

    const body = await req.json()

    const { 
      
        gender,
        password,
        isActive,
        jobType,
        jobRole,
        department,
        data

    } = FormSchema.parse(body);

    const {firstName,lastName,startDate,companyEmail,address,salary}=data

  try {
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user record using Prisma client
    const newMember = await prisma.user.create({
      data: {
        gender,
        password:hashedPassword,
        isActive,
        jobType,
        role:jobRole,
        department,
        firstName,
        lastName,
        startDate,
        email:companyEmail,
        address,
        profilePic:"",
        bio:"",
        salary:parseInt(salary)
      },
    });


    // Generate JWT token for user ID
    const jwtUserId = signJwt({
      id: newMember.id,
    });

    return NextResponse.json({ status:"success", newMember});
  } catch (error) {
    console.error('Error creating user:', error);
    throw error; 
  } finally {
    await prisma.$disconnect(); // Disconnect from the Prisma client
  }
}
