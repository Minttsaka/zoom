import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';
import { signJwt } from '@/lib/jwt'; // Assuming you have a function for signing JWT tokens
import { z } from 'zod';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
  
const FormSchema = z.object({
    fileKey: z.string(),
    heading: z.string(),
    content: z.string(),
  });
  

  export async function POST(req: Request, res: Response) {

    const body = await req.json()

    const {fileKey,content,heading} = FormSchema.parse(body);


  try {
    // Hash the password
 
    // Create a new user record using Prisma client
    const newImpact = await prisma.impact.create({
      data: {
        title:heading,
        content,
        image:fileKey,
      },
    });



    return NextResponse.json({ status:"success", newImpact});
  } catch (error) {
    console.error('Error creating user:', error);
    throw error; 
  } finally {
    await prisma.$disconnect(); // Disconnect from the Prisma client
  }
}
