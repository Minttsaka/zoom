import { NextResponse } from "next/server";
import { limiter } from "../config/limiter";
import { prisma } from "@/lib/prisma";



type SocialMediaEntry = {
    id: string; userId: string; socialMedia: string;
  }
  
  type User = {
    firstName: string;
    lastName: string;
    role: string;
    bio: string;
    profilePic: string;
    socialMedia: SocialMediaEntry[]; // Ensure socialMedia is an array of SocialMediaEntry objects
  }
  

export async function GET(req:Request){
    const remaining = await limiter.removeTokens(1)

    const origin=req.headers.get('origin')

    try {
        
    const users = await prisma.user.findMany({
        include: {
            socialMedia: true,
          },
      });

      const modifiedUsers = users.map(({id, startDate,isActive,salary,address, email,jobType,gender, ...users}) => ({
        users
    }));
    
    return new NextResponse(JSON.stringify(modifiedUsers),{
        headers: {
            'Access-Control-Allow-Origin': origin || "*",
            'Content-Type':'application/json',
          },
    })
    } catch (error) {
        return 
    }


}