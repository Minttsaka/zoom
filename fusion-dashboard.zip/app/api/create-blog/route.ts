
import { z } from 'zod';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
  
const FormSchema = z.object({
    fileKey: z.string(),
    heading: z.string(),
    content: z.string(),
    category: z.string(),

  });

  interface User {
    name?: string | null;
    email?: string | null;
    image?: string | null;
    firstName?: string | null;
    lastName?: string | null;
  }
  

  export async function POST(req: Request, res: Response) {

    const session = await getServerSession(authOptions);
    const { firstName, lastName } = (session?.user || {}) as User;

    if(!session){
      redirect('/')
    }


    const body = await req.json()

    const {fileKey,content,heading,category} = FormSchema.parse(body);

  try {
   
    const newBlog = await prisma.blog.create({
      data: {
        profilePic:fileKey,
        title:heading,
        category,
        author:`${firstName} ${lastName}`,
        content,
        image:fileKey,
      },
    });

    return NextResponse.json({ status:"success"});
  } catch (error) {
    console.error('Error creating user:', error);
    throw error; 
  } finally {
    await prisma.$disconnect(); // Disconnect from the Prisma client
  }
}
