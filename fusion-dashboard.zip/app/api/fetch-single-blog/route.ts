import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const FormSchema = z.object({
  id: z.string(),
});


export async function POST(req:Request){

    const origin=req.headers.get('origin')

    const body = await req.json()

    const {id} = FormSchema.parse(body);

    try {
        
    const blog = await prisma.blog.findUnique(
      {
        where:{
          id
        }
      }
    );

    const allBlog = await prisma.blog.findMany()


      return new NextResponse(JSON.stringify({blog,allBlog}),{
        headers: {
            'Access-Control-Allow-Origin': origin || "*",
            'Content-Type':'application/json',
          },
    })
    } catch (error) {
        return
    }


}