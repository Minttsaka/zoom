import { PrismaClient } from '@prisma/client'
import { NextResponse } from 'next/server';
import { z } from 'zod';

const prisma = new PrismaClient()

const FormSchema = z.object({
    firstName: z.string().max(255, "University name must be less than 255 characters"),
    lastName: z.string().max(255, "Year name must be less than 255 characters"),
    bio: z.string(),
    fileKey:z.string(),
    userId: z.string().max(255, "Year name must be less than 255 characters"),
    socials: z.array(
        z.object({
          path: z.string(), 
          url: z.string(),
        })
      ),
  });


export async function POST(req: Request, res: Response) {

    const body = await req.json()

    const { 
        userId,
        firstName,
        lastName,
        fileKey,
        bio,
        socials} = FormSchema.parse(body);



    try {
      
const updatedUser = await prisma.user.update({
  where: { id: userId }, 
  data: {
    profilePic:fileKey,
    firstName,
    bio,
    lastName,
  },
});

  await prisma.social.deleteMany({
    where: { userId: updatedUser.id }, 
  });

  for (const socialMedia of socials!) {
    await prisma.social.create({
      data: {
        socialMedia: socialMedia.path,
        user: { connect: { id: updatedUser.id } },
      },
    });
  }

      return NextResponse.json({ status:"success"});

    } catch (error) {
      console.error('Error creating user:', error);
      return NextResponse.json({ status:"failed"});
    } finally {
      await prisma.$disconnect();
    }
  }