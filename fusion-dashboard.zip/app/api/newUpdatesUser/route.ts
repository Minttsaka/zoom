import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const FormSchema = z.object({
  email: z.string().email(),
});


export async function POST(req:Request){

    const origin=req.headers.get('origin')

    const body = await req.json()

    const {email} = FormSchema.parse(body);

    try {
        
    const updatesUsers = await prisma.updateUser.create(
      {
        data:{
        email
      }
    }
    );

      return new NextResponse(JSON.stringify({data:'success'}),{
        headers: {
            'Access-Control-Allow-Origin': origin || "*",
            'Content-Type':'application/json',
          },
    })
    } catch (error) {
      return new NextResponse(JSON.stringify({data:'failed'}),{
        headers: {
            'Access-Control-Allow-Origin': origin || "*",
            'Content-Type':'application/json',
          },
    })
    }


}