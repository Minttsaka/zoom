import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const FormSchema = z.object({
  category: z.string(),
});


export async function POST(req:Request){

    const origin=req.headers.get('origin')

    const body = await req.json()

    const {category} = FormSchema.parse(body);

    try {
        
    const updatesCategory = await prisma.blog.findMany(
      {
        where:{
        category
      }
    }
    );

      return new NextResponse(JSON.stringify(updatesCategory),{
        headers: {
            'Access-Control-Allow-Origin': origin || "*",
            'Content-Type':'application/json',
          },
    })
    } catch (error) {
        return
    }


}