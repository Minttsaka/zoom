import NavBar from '@/components/navBar'
import { Profile } from '@/components/profile'
import React from 'react'

type Prop={
  params:{
    id:string
  }
}

export default function page({params}:Prop) {

  const id=params.id

  return (
    <div className='flex'>
      <NavBar />
      <Profile userId={id} />
    </div>
  )
}
