import GlobalNav from '@/components/GlobalNav'
import { TextEditor } from '@/components/text-editor'
import React from 'react'

export default function page() {
  return (
    <div className='flex'>
      <GlobalNav />
      <TextEditor />
    </div>
  )
}
