import { AddEmployee } from '@/components/add-employee'
import NavBar from '@/components/navBar'
import React from 'react'

export default function page() {
  return (
    <div className='flex'>
      <NavBar />
      <AddEmployee />
    </div>
  )
}
