import GlobalNav from '@/components/GlobalNav'
import { RevenueDashboard } from '@/components/revenue-dashboard'
import React from 'react'

export default function page() {
  return (
    <div className='flex'>
      <GlobalNav />
      <RevenueDashboard />
    </div>
  )
}
