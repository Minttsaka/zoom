import GlobalNav from '@/components/GlobalNav'
import NavBar from '@/components/navBar'
import { Softwares } from '@/components/softwares'
import React from 'react'

export default function page() {
  return (
    <div className='flex'>
      <NavBar />
      <Softwares />
    </div>
  )
}
