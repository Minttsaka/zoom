import MobileNav from "@/components/mobileNav";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "dctfusion",
  description: "THIS IS RESTRICTED SITE",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <div>
        <div >
          <div className="w-full overflow-y-auto h-screen">{children}</div>
      </div>
    </div>
  );
}
