import GlobalNav from '@/components/GlobalNav'
import { AddSoftware } from '@/components/add-software'
import React from 'react'

export default function page() {
  return (
    <div className='flex'>
      <GlobalNav />
      <AddSoftware />
    </div>
  )
}
