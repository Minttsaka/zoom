import { Dashboard } from '@/components/dashboard'
import NavBar from '@/components/navBar'
import React from 'react'

export default function page() {
  return (
    <div className='flex'>
      <NavBar/>
      <Dashboard />
    </div>
  )
}
