"use client"

import { Login } from "@/components/login";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function Home() {

  const router=useRouter()

  const { data: session } = useSession();

    if (session) {
      router.push('/dashboard')
    }


  return (
   <div >
    <p className="text-black text-xl">
      <Login />
    </p>
   </div>
  );
}
