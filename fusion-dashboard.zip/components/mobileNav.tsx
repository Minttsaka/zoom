import React from 'react'

export default function MobileNav() {
  return (
    <div className="fixed left-1/2 z-50 right-0 top-0 bottom-0 ">
      <aside className=" overflow-y-auto md:hidden block h-screen  bg-[#2c3e50] text-white">
        <div className="px-4 py-6">
          <h2 className="font-semibold">Dctfusion</h2>
          <nav className="mt-8">
            <h3 className="text-xs uppercase tracking-wide text-gray-400">company</h3>
            <ul className="mt-2 space-y-1">
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium bg-green-600 rounded-md" href="/dashboard">
                  <BarChartIcon className="w-4 h-4 mr-3" />
                  Home
                </a>
              </li>
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="/dashboard/revenue">
                  <ShoppingCartIcon className="w-4 h-4 mr-3" />
                  Revenues
                </a>
              </li>
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <LineChartIcon className="w-4 h-4 mr-3" />
                  Sales
                </a>
              </li>
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <PieChartIcon className="w-4 h-4 mr-3" />
                  Expenses
                </a>
              </li>
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <ScatterChartIcon className="w-4 h-4 mr-3" />
                  Team
                </a>
              </li>
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="/dashboard/blog">
                  <PuzzleIcon className="w-4 h-4 mr-3" />
                  Blog
                </a>
              </li>
            </ul>
            <h3 className="mt-8 text-xs uppercase tracking-wide text-gray-400">Softwares</h3>
            <ul className="mt-2 space-y-1">
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="/dashboard/softwares">
                  <BoxesIcon className="w-4 h-4 mr-3" />
                  Softwares
                </a>
              </li>
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <TableIcon className="w-4 h-4 mr-3" />
                  Library
                </a>
              </li>
            </ul>
            <h3 className="mt-8 text-xs uppercase tracking-wide text-gray-400">Dashboard Widgets</h3>
            <ul className="mt-2 space-y-1">
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <AreaChartIcon className="w-4 h-4 mr-3" />
                  Chart Boxes 1
                </a>
              </li>
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <BarChartIcon className="w-4 h-4 mr-3" />
                  Chart Boxes 2
                </a>
              </li>
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <PieChartIcon className="w-4 h-4 mr-3" />
                  Chart Boxes 3
                </a>
              </li>
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <UserCircleIcon className="w-4 h-4 mr-3" />
                  Profile Boxes
                </a>
              </li>
            </ul>
            <h3 className="mt-8 text-xs uppercase tracking-wide text-gray-400">Forms</h3>
            <ul className="mt-2 space-y-1">
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <ClipboardListIcon className="w-4 h-4 mr-3" />
                  Elements
                </a>
              </li>
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <SlidersIcon className="w-4 h-4 mr-3" />
                  Widgets
                </a>
              </li>
            </ul>
            <h3 className="mt-8 text-xs uppercase tracking-wide text-gray-400">Charts</h3>
            <ul className="mt-2 space-y-1">
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <LineChartIcon className="w-4 h-4 mr-3" />
                  Chart.js
                </a>
              </li>
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <AreaChartIcon className="w-4 h-4 mr-3" />
                  Apex Charts
                </a>
              </li>
              <li>
                <a className="flex items-center px-4 py-2 text-sm font-medium hover:bg-green-700 rounded-md" href="#">
                  <PieChartIcon className="w-4 h-4 mr-3" />
                  Chart Sparklines
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </aside>
    </div>
  )
}


function AreaChartIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M3 3v18h18" />
        <path d="M7 12v5h12V8l-5 5-4-4Z" />
      </svg>
    )
  }

function BarChartIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <line x1="12" x2="12" y1="20" y2="10" />
        <line x1="18" x2="18" y1="20" y2="4" />
        <line x1="6" x2="6" y1="20" y2="16" />
      </svg>
    )
  }
  
  
  function BellIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
        <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
      </svg>
    )
  }
  
  
  function BoxesIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M2.97 12.92A2 2 0 0 0 2 14.63v3.24a2 2 0 0 0 .97 1.71l3 1.8a2 2 0 0 0 2.06 0L12 19v-5.5l-5-3-4.03 2.42Z" />
        <path d="m7 16.5-4.74-2.85" />
        <path d="m7 16.5 5-3" />
        <path d="M7 16.5v5.17" />
        <path d="M12 13.5V19l3.97 2.38a2 2 0 0 0 2.06 0l3-1.8a2 2 0 0 0 .97-1.71v-3.24a2 2 0 0 0-.97-1.71L17 10.5l-5 3Z" />
        <path d="m17 16.5-5-3" />
        <path d="m17 16.5 4.74-2.85" />
        <path d="M17 16.5v5.17" />
        <path d="M7.97 4.42A2 2 0 0 0 7 6.13v4.37l5 3 5-3V6.13a2 2 0 0 0-.97-1.71l-3-1.8a2 2 0 0 0-2.06 0l-3 1.8Z" />
        <path d="M12 8 7.26 5.15" />
        <path d="m12 8 4.74-2.85" />
        <path d="M12 13.5V8" />
      </svg>
    )
  }
  
  
  function ClipboardListIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <rect width="8" height="4" x="8" y="2" rx="1" ry="1" />
        <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
        <path d="M12 11h4" />
        <path d="M12 16h4" />
        <path d="M8 11h.01" />
        <path d="M8 16h.01" />
      </svg>
    )
  }
  

  
  function LineChartIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M3 3v18h18" />
        <path d="m19 9-5 5-4-4-3 3" />
      </svg>
    )
  }
  
  
  function MailboxIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M22 17a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9.5C2 7 4 5 6.5 5H18c2.2 0 4 1.8 4 4v8Z" />
        <polyline points="15,9 18,9 18,11" />
        <path d="M6.5 5C9 5 11 7 11 9.5V17a2 2 0 0 1-2 2v0" />
        <line x1="6" x2="7" y1="10" y2="10" />
      </svg>
    )
  }
  
  
  function PieChartIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M21.21 15.89A10 10 0 1 1 8 2.83" />
        <path d="M22 12A10 10 0 0 0 12 2v10z" />
      </svg>
    )
  }
  
  
  function PuzzleIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M19.439 7.85c-.049.322.059.648.289.878l1.568 1.568c.47.47.706 1.087.706 1.704s-.235 1.233-.706 1.704l-1.611 1.611a.98.98 0 0 1-.837.276c-.47-.07-.802-.48-.968-.925a2.501 2.501 0 1 0-3.214 3.214c.446.166.855.497.925.968a.979.979 0 0 1-.276.837l-1.61 1.61a2.404 2.404 0 0 1-1.705.707 2.402 2.402 0 0 1-1.704-.706l-1.568-1.568a1.026 1.026 0 0 0-.877-.29c-.493.074-.84.504-1.02.968a2.5 2.5 0 1 1-3.237-3.237c.464-.18.894-.527.967-1.02a1.026 1.026 0 0 0-.289-.877l-1.568-1.568A2.402 2.402 0 0 1 1.998 12c0-.617.236-1.234.706-1.704L4.23 8.77c.24-.24.581-.353.917-.303.515.077.877.528 1.073 1.01a2.5 2.5 0 1 0 3.259-3.259c-.482-.196-.933-.558-1.01-1.073-.05-.336.062-.676.303-.917l1.525-1.525A2.402 2.402 0 0 1 12 1.998c.617 0 1.234.236 1.704.706l1.568 1.568c.23.23.556.338.877.29.493-.074.84-.504 1.02-.968a2.5 2.5 0 1 1 3.237 3.237c-.464.18-.894.527-.967 1.02Z" />
      </svg>
    )
  }
  
  
  function ScatterChartIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <circle cx="7.5" cy="7.5" r=".5" />
        <circle cx="18.5" cy="5.5" r=".5" />
        <circle cx="11.5" cy="11.5" r=".5" />
        <circle cx="7.5" cy="16.5" r=".5" />
        <circle cx="17.5" cy="14.5" r=".5" />
        <path d="M3 3v18h18" />
      </svg>
    )
  }
  
  
  function SearchIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <circle cx="11" cy="11" r="8" />
        <path d="m21 21-4.3-4.3" />
      </svg>
    )
  }
  
  
  function ShoppingCartIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <circle cx="8" cy="21" r="1" />
        <circle cx="19" cy="21" r="1" />
        <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" />
      </svg>
    )
  }
  
  
  function SlidersIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <line x1="4" x2="4" y1="21" y2="14" />
        <line x1="4" x2="4" y1="10" y2="3" />
        <line x1="12" x2="12" y1="21" y2="12" />
        <line x1="12" x2="12" y1="8" y2="3" />
        <line x1="20" x2="20" y1="21" y2="16" />
        <line x1="20" x2="20" y1="12" y2="3" />
        <line x1="2" x2="6" y1="14" y2="14" />
        <line x1="10" x2="14" y1="8" y2="8" />
        <line x1="18" x2="22" y1="16" y2="16" />
      </svg>
    )
  }
  
  
  function TableIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M12 3v18" />
        <rect width="18" height="18" x="3" y="3" rx="2" />
        <path d="M3 9h18" />
        <path d="M3 15h18" />
      </svg>
    )
  }
  
  
  function UserCircleIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <circle cx="12" cy="12" r="10" />
        <circle cx="12" cy="10" r="3" />
        <path d="M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662" />
      </svg>
    )
  }
  
  
  function UsersIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    )
  }
  
  
  function WalletIcon(props: React.JSX.IntrinsicAttributes & React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M21 12V7H5a2 2 0 0 1 0-4h14v4" />
        <path d="M3 5v14a2 2 0 0 0 2 2h16v-5" />
        <path d="M18 12a2 2 0 0 0 0 4h4v-4Z" />
      </svg>
    )
  }
  

