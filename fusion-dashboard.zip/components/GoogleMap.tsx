"use client"

const API_KEY = 'AIzaSyC2G7lrFJPcAch3t_Fz0ld8ltRPOic1R8k';

const GoogleMap = () => {

  return (
    <div className="shadow-lg ">
      <iframe
      className='w-full'
      height="450"
      loading="lazy"
      allowFullScreen
      referrerPolicy="no-referrer-when-downgrade"
      src={`https://www.google.com/maps/embed/v1/place?key=${API_KEY}
      &q=Space+Needle,Seattle+WA`}>
</iframe>
    </div>
  );
};

export default GoogleMap;
